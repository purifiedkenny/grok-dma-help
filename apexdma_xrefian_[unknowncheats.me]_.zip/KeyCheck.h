#pragma once

namespace KeyCheck {
	void run();
}